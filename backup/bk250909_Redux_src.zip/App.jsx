import './App.css';
import List from './components/List.jsx';
import Detail from './components/Detail.jsx';

function App() {
  return (
    <>
      <List></List>
      <hr />
      <Detail></Detail>
    </>
  )
}

export default App;